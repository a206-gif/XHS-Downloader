from asyncio import sleep
from math import log
from random import lognormvariate
from typing import Callable

from rich import print
from rich.text import Text

from ..translation import _
from .static import INFO


def retry(function):
    async def inner(self, *args, **kwargs):
        if result := await function(self, *args, **kwargs):
            return result
        for __ in range(self.retry):
            if result := await function(self, *args, **kwargs):
                return result
        return result

    return inner


def retry_limited(function):
    # TODO: 不支持 TUI
    def inner(self, *args, **kwargs):
        while True:
            if function(self, *args, **kwargs):
                return
            if self.console.input(
                _(
                    "如需重新尝试处理该对象，请关闭所有正在访问该对象的窗口或程序，然后直接按下回车键！\n"
                    "如需跳过处理该对象，请输入任意字符后按下回车键！"
                ),
            ):
                return

    return inner


def logging(log: Callable, text, style=INFO):
    string = Text(text, style=style)
    func = log()
    if func is print:
        func(string)
    else:
        func.write(
            string,
            scroll_end=True,
        )


def get_site_referer(url: str | None) -> str:
    if "rednote" in (url or "").lower():
        return "https://www.rednote.com/"
    return "https://www.xiaohongshu.com/"


def compare_versions(
    current_version: str,
    target_version: str,
    is_development: bool,
) -> int:
    """比较两个主版本号，返回正式版更新状态码。"""

    current = tuple(map(int, current_version.removeprefix("v").split(".")[:2]))
    target = tuple(map(int, target_version.removeprefix("v").split(".")[:2]))
    if target > current:
        return 4
    if target == current:
        return 3 if is_development else 1
    return 2 if is_development else 1


def get_wait_time(
    avg_delay: float | int = 6.0,
    sigma: float = 0.6,
) -> float:
    mu = log(avg_delay) - (sigma**2 / 2)
    delay = lognormvariate(mu, sigma)
    min_delay = avg_delay * 0.2
    max_delay = avg_delay * 5
    return max(min_delay, min(max_delay, delay))


async def sleep_time(avg_delay: float | int = 6.0):
    await sleep(get_wait_time(avg_delay))
