XHS-Downloader V2.9 Beta - Windows 10/11 x64
=============================================

双击 XHS-Downloader.exe 运行图形界面（需系统安装 Microsoft Edge WebView2）。

命令行用法（在 exe 所在目录打开 cmd）:
  XHS-Downloader.exe --version
  XHS-Downloader.exe -u <小红书作品链接或作者主页链接>
  XHS-Downloader.exe TUI     终端界面
  XHS-Downloader.exe API     API 服务

更新内容:
- 支持输入作者主页链接，自动解析作者全部作品
- 作者主页模式下默认保存每个作品的文案信息（txt）

结构: XHS-Downloader.exe 为启动器，python/ 为内置 Python 3.15 运行时及依赖，app/ 为程序代码。
