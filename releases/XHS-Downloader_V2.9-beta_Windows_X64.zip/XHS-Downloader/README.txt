XHS-Downloader V2.9 Beta - Windows 10/11 x64（基于原仓库 JoeanAmier/XHS-Downloader 代码 + 新功能）
=============================================================================================

【重要】请先完整解压本 zip，再双击 XHS-Downloader.exe（直接在压缩包预览中运行会被 Windows 拦截）。

双击 XHS-Downloader.exe 运行图形界面（需系统安装 Microsoft Edge WebView2）。

命令行用法（在 exe 所在目录打开 cmd 或 PowerShell）:
  XHS-Downloader.exe --version
  XHS-Downloader.exe -u <小红书作品链接或作者主页链接>
  XHS-Downloader.exe TUI     终端界面（推荐，无需 WebView2）
  XHS-Downloader.exe API     API 服务

新增功能:
- 支持输入作者主页链接（/user/profile/xxx），自动解析作者全部作品
- 作者主页模式下默认保存每个作品的文案信息（txt）
