@echo off
cd /d "%~dp0\.."
python\python.exe app\main.py TUI
