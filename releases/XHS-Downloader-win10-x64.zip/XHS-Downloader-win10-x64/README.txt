XHS-Downloader V2.9 Beta - Windows 10 x64 便携版
=================================================

无需安装 Python，解压后双击 XHS-Downloader.bat 即可运行图形界面。

命令行用法（在 cmd 中运行）:
  python\python.exe app\main.py --version
  python\python.exe app\main.py -u <小红书作品链接或作者主页链接>
  python\python.exe app\main.py TUI        终端界面
  python\python.exe app\main.py API        API 服务

功能更新:
- 支持输入作者主页链接，自动解析作者全部作品
- 作者主页模式下默认保存每个作品的文案信息（txt）

注意: 图形界面需要系统安装 Microsoft Edge WebView2 运行时。
