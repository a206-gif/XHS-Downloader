@echo off
cd /d "%~dp0"
if "%~1"=="" (
    start "" python\pythonw.exe app\main.py
) else (
    python\python.exe app\main.py %*
)
